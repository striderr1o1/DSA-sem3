// #include<iostream>
// #include<queue>
// using namespace std;


// struct Node {
//     char ch;      
//     int freq;         
//     Node* left;
//     Node* right;
//     Node( char c, int f) {
//         ch = c; 
//         freq = f;
//         left = nullptr; 
//         right = nullptr;
//     }
//     Node(int f, Node* l, Node* r) {
// 		ch = 0;                  
//         freq = f;
//         left = l;
//         right = r;
//     }
//     ~Node() { 
//         delete left;
//         delete right;
//     }
// };

// // to find 2 nodes with least frequency like smaller freq will be given higher priority
// struct NodeCompare {
//     bool operator()(const Node* a, const Node* b) const {
//         return a->freq > b->freq; // smaller freq = higher priority
//     }
// };



// // Traverse tree to build codes
// void buildCodes(Node* root, const string&  num, vector<string>& codes) {
//     if (!root) return;
//     // leaf -> store code
//     if (!root->left && !root->right) {
//         // if prefix empty (only one unique char), assign "0"
//         if (num.empty()) {
//             codes[root->ch] = "0";
//         }
//         else {
//             codes[root->ch] = num;
//         }
//         return;
//     }
//     buildCodes(root->left, num + '0', codes);
//     buildCodes(root->right, num + '1', codes);
// }

#include<iostream>
#include<fstream>
#include<string>
#include <sstream>//This is a header used to tread and use string as stream i.e we can read string in a flow. // we use ostringstream form this library. 
using namespace std;

// file size function
long long getFileSize(const string &filename){
    ifstream file(filename, ios::binary | ios::ate);//ios::binary opens file in binary and ios::ate take the pointer to end of the file for accureate and complete size of file in bytes;
    if(!file.is_open()){
        throw runtime_error("file not found  " + filename);
    }
    return file.tellg();// returns the position of the pointer in bytes ios :: ate took the pointer to the end of the file and  tellg tell the position in bytes
}

string readFile(const string &filename){
    ifstream file(filename);
    if(!file.is_open()){
        throw runtime_error("file not found  " + filename);
    }
    // using sstream library creating a buffer to store the file using osteamstring
    ostringstream buffer;
    buffer << file.rdbuf();// reads the whole file and temporaryly stores to buffer as string
    return buffer.str();
}
int main(){
    try {
        string content = readFile("hamid.txt");
        cout<< "File contains:"<<endl<< content << endl;

    }
    catch(const exception &e){
        cerr<< e.what()<<endl;
    }
      try {
        cout<< getFileSize("hamid.txt")<<endl;
    }
    catch(const exception &e){
        cerr<< e.what()<<endl;
    }
return 0;
}