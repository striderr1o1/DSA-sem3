let InputTag = document.querySelector('input');
let inputButton = document.querySelector('button');

inputButton.addEventListener('click', function(){
    fetch(`http://127.0.0.1:18080/sendFile/${InputTag.value}`)
    .then((response)=>{
        let div = document.querySelector('.response');
        console.log(response);
    })
})